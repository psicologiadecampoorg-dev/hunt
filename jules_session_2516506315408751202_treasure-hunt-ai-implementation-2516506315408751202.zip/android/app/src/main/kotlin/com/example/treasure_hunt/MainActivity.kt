package com.example.treasure_hunt

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
