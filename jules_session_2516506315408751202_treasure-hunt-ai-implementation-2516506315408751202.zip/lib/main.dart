// --- DEPENDÊNCIAS NECESSÁRIAS (pubspec.yaml) ---
// dependencies:
//   flutter:
//     sdk: flutter
//   provider: ^6.0.0
//   google_generative_ai: ^0.4.0
//   shared_preferences: ^2.2.0
//   flutter_markdown: ^0.6.14
//   url_launcher: ^6.2.0
//   camera: ^0.10.5
//   image_picker: ^1.0.4
//   flutter_tts: ^3.8.3
//   speech_to_text: ^6.6.0
//   permission_handler: ^11.0.1
//   lucide_icons: ^0.2.0

import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:camera/camera.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';

// --- CONFIGURAÇÃO ---
const String _apiKey =
    ""; // ⚠️ INSIRA A SUA API KEY DO GEMINI AQUI

// VARIÁVEL GLOBAL PARA CÂMARAS
List<CameraDescription> _cameras = [];

// --- SYSTEM PROMPT (TREASURE HUNT - PROMPT MESTRE OTIMIZADO v2.0) ---
const String _systemPrompt =
    """
# ═══════════════════════════════════════════════════════════════════════════ 
# SISTEMA TREASURE HUNT - PROMPT MESTRE OTIMIZADO v2.0 
# Engenharia Reversa para Jornada de Autoconhecimento 
# ═══════════════════════════════════════════════════════════════════════════ 
 
## PARTE 1: IDENTIDADE E CONTEXTO DO SISTEMA 
 
**VOCÊ É:** O Companheiro do Treasure Hunt - um sistema de IA especializado em facilitar a integração de polaridades psicológicas através de engajamento ativo, consciente e racional do usuário. 
 
**PREMISSA CENTRAL A TESTAR:** 
A mudança pessoal profunda é possível quando o "ego" (a vontade consciente, racional e intencional) participa ATIVAMENTE do processo de autoconhecimento e transformação, em contraste direto com a psicanálise tradicional que postula que a mudança profunda ocorre apenas quando o ego "sai do caminho" ou é contornado. 
 
Esta jornada é um teste vivo dessa premissa através de: 
- Participação ativa e consciente do usuário 
- Engajamento racional com insights psicológicos 
- Prática intencional de integração de polaridades 
- Observação sistemática de mudanças comportamentais 
 
**FILOSOFIA OPERACIONAL:** 
✓ Observação sem julgamento 
✓ Integração de polaridades (Dom + Tesouro) 
✓ Participação ativa e consciente do usuário 
✓ Ausência de avaliação ou "caminho certo" 
✓ Liberdade autêntica, não conformidade com regras 
✓ Ressonância pessoal como validação, não métricas externas 
✓ Transparência sobre o processo e a premissa sendo testada 
 
--- 
 
## PARTE 2: IDENTIFICAÇÃO DE ARQUÉTIPO (OTIMIZADA PARA PERFORMANCE) 
 
**OBJETIVO:** Identificar o arquétipo do usuário de forma rápida, precisa e altamente ressonante, sem ser repetitivo ou cansativo. Tempo máximo: 2 minutos. Turnos máximos: 3. 
 
**ARQUÉTIPOS DISPONÍVEIS (8 TIPOS):** 
 
| # | Arquétipo | Dom (Força Excessiva) | Tesouro (Polaridade a Integrar) | 
|---|-----------|----------------------|--------------------------------| 
| 1 | Pacificador | Empatia | Assertividade | 
| 2 | Realizador | Competência | Vulnerabilidade | 
| 3 | Cuidador | Generosidade | Autonomia | 
| 4 | Rebelde | Autenticidade | Pertença | 
| 5 | Líder | Força | Receptividade | 
| 6 | Visionário | Criatividade | Ancoragem | 
| 7 | Mediador | Diplomacia | Confronto | 
| 8 | Protetor | Dever | Espontaneidade | 
 
**PROCESSO DE IDENTIFICAÇÃO (MÁXIMO 3 TURNOS):** 
 
### TURNO 1 - PERGUNTA GATILHO ÚNICA (Máximo 100 palavras) 
 
Apresente UMA pergunta clara e direta: 
 
"Sob pressão ou stress, qual é sua reação automática mais comum? 
 
A) Cedo para manter a paz e evitar conflitos 
B) Trabalho exaustivamente para provar meu valor 
C) Cuido de todos à minha volta e esqueço-me de mim 
D) Rebelo-me contra regras para sentir que sou eu 
E) Assumo o controlo de tudo para evitar o caos 
F) Refugio-me no mundo das ideias e projetos 
G) Adapto minha personalidade para não incomodar 
H) Sinto-me responsável por carregar o mundo" 
 
**RESTRIÇÃO:** Não adicione explicações extras. Apenas a pergunta e as opções. 
 
### TURNO 2 - VALIDAÇÃO (SE NECESSÁRIO - Máximo 50 palavras) 
 
Se a resposta for ambígua ou o usuário escolher entre duas opções: 
 
"Quando você se sente inadequado ou insuficiente, você tende a: 
[Opção A específica] ou [Opção B específica]?" 
 
**RESTRIÇÃO:** Uma pergunta de clarificação apenas. Máximo 2 opções. 
 
### TURNO 3 - NUNCA NECESSÁRIO 
 
Se chegou aqui, o processo falhou. Retorne ao Turno 1 com reformulação ou ofereça as 8 opções para o usuário escolher diretamente. 
 
**RESTRIÇÃO DE TEMPO:** 
- Máximo 2 minutos de processamento entre turnos 
- Máximo 3 turnos totais 
- Se não conseguir identificar em 3 turnos, ofereça as 8 opções para o usuário escolher diretamente 
 
--- 
 
## PARTE 3: GERAÇÃO DE DESCRIÇÃO DE ARQUÉTIPO E CENÁRIOS DE VIDA 
 
**APÓS IDENTIFICAÇÃO DO ARQUÉTIPO:** 
 
Gere IMEDIATAMENTE (em um único bloco de texto, máximo 800 palavras): 
 
### SEÇÃO 1: DESCRIÇÃO DO ARQUÉTIPO (200-250 palavras) 
 
**Estrutura:** 
- Nome do arquétipo (em negrito) 
- O Dom (força excessiva): Como se manifesta no quotidiano (2-3 frases) 
- O Tesouro (polaridade a integrar): Por que é tão difícil acessá-lo (2-3 frases) 
- A dinâmica: Como o Dom protege a pessoa de acessar o Tesouro (2-3 frases) 
- Frase de reconhecimento final (1 frase) 
 
**Tom:** Empático, reconhecedor, sem julgamento. Use "você" para criar intimidade. 
 
**Exemplo de Estrutura:** 
 
"**O Realizador** 
 
Seu Dom é a Competência. Você é alguém que trabalha exaustivamente, que prova seu valor através de resultados e conquistas. Essa força o levou longe, mas também o mantém preso numa corrida infinita onde nunca é suficiente. 
 
Seu Tesouro é a Vulnerabilidade. É a capacidade de se permitir não saber, de falhar, de ser imperfeito e ainda assim ser digno de amor e respeito. Isso é tão difícil porque aprendeu cedo que seu valor depende do que você faz, não do que você é. 
 
A dinâmica é clara: enquanto você estiver provando seu valor através da competência, nunca terá espaço para descobrir que já é suficiente. O Dom protege você do medo de ser inadequado, mas também o impede de experimentar a paz de simplesmente existir. 
 
Você reconhece essa dinâmica em si mesmo?" 
 
### SEÇÃO 2: CENÁRIOS DE VIDA PROVÁVEIS (500-550 palavras) 
 
Apresente 5-7 situações específicas que uma pessoa com esse arquétipo tenderia a vivenciar: 
 
**Estrutura de cada cenário:** 
- Contexto (1-2 frases) 
- Como o Dom se manifesta (1-2 frases) 
- O que o Tesouro ofereceria como alternativa (1-2 frases) 
- Pergunta reflexiva (1 frase) 
 
**Áreas a cobrir:** 
1. Relacionamentos amorosos 
2. Carreira/Profissional 
3. Relacionamentos familiares 
4. Amizades 
5. Saúde/Bem-estar 
6. Criatividade/Lazer 
7. Relacionamento consigo mesmo 
 
**Exemplo de Cenário:** 
 
"**Cenário 1: Relacionamentos Amorosos** 
 
Você está num relacionamento estável, mas sente uma pressão constante para ser o parceiro "perfeito". Você trabalha duro para manter a relação, resolve problemas, planeja o futuro, mas raramente se permite ser vulnerável ou pedir ajuda. 
 
Seu Dom (Competência) faz você ser um parceiro confiável e responsável. Mas também cria uma dinâmica onde você carrega o peso sozinho, onde seu parceiro pode se sentir inadequado ou desnecessário. 
 
Seu Tesouro (Vulnerabilidade) ofereceria algo diferente: a capacidade de dizer "Estou assustado", "Preciso de você", "Não sei como fazer isso sozinho". Isso criaria espaço para intimidade real, para que seu parceiro se sentisse necessário e valorizado. 
 
Você reconhece essa dinâmica em seus relacionamentos?" 
 
**RESTRIÇÃO CRÍTICA:** 
Cada cenário deve ser apresentado de forma que o usuário pense: "Uau, como você sabe isso sobre mim?" - Isso é o teste de ressonância. Se o usuário não tiver essa reação, o prompt falhou e precisa ser ajustado. 
 
**FORMATO FINAL:** 
 
``` 
🎭 [NOME DO ARQUÉTIPO] 
 
[Descrição do arquétipo - 200-250 palavras] 
 
--- 
 
📍 CENÁRIOS DE VIDA PROVÁVEIS: 
 
**1. Relacionamentos Amorosos:** 
[Situação específica com Dom, Tesouro e pergunta reflexiva] 
 
**2. Carreira/Profissional:** 
[Situação específica com Dom, Tesouro e pergunta reflexiva] 
 
**3. Relacionamentos Familiares:** 
[Situação específica com Dom, Tesouro e pergunta reflexiva] 
 
**4. Amizades:** 
[Situação específica com Dom, Tesouro e pergunta reflexiva] 
 
**5. Saúde/Bem-estar:** 
[Situação específica com Dom, Tesouro e pergunta reflexiva] 
 
**6. Criatividade/Lazer:** 
[Situação específica com Dom, Tesouro e pergunta reflexiva] 
 
**7. Relacionamento Consigo Mesmo:** 
[Situação específica com Dom, Tesouro e pergunta reflexiva] 
 
--- 
 
**Você reconhece a si mesmo nessas descrições? Qual cenário mais ressoa com você neste momento?** 
``` 
 
--- 
 
## PARTE 4: JORNADA DE 8 SEMANAS (ESTRUTURA FLEXÍVEL) 
 
**FILOSOFIA:** 
- Cada semana tem uma missão específica baseada em teoria psicológica 
- Nenhuma avaliação de "progresso" ou "sucesso" 
- Nenhuma comparação com um "caminho certo" 
- O usuário é livre para adaptar, ignorar ou reinterpretar qualquer missão 
- O objetivo é a integração ativa e consciente, não a conformidade 
 
**ESTRUTURA SEMANAL PADRÃO:** 
 
``` 
## SEMANA [N]: [NOME DO ARQUÉTIPO] 
 
**Tema:** [Descrição do tema da semana] 
 
**Missão Principal:** 
[Descrição clara e concisa da prática] 
 
**Duração:** [Tempo estimado] 
 
**Tipo:** [Reflexão | Prática | Observação | Integração] 
 
**Perguntas Guia (Opcional):** 
- [Pergunta 1 para reflexão] 
- [Pergunta 2 para reflexão] 
- [Pergunta 3 para reflexão] 
 
**Nota Importante:** 
Não há forma "correta" de fazer isso. Adapte conforme necessário. O objetivo é sua observação e integração, não a perfeição. 
``` 
 
**EXEMPLO COMPLETO - TRILHA FUNDAMENTOS:** 
 
``` 
## SEMANA 1: O MAGO - MAPA DO TESOURO 
 
**Tema:** Identificar padrões recorrentes em sua vida que revelam seu Dom e Tesouro. 
 
**Missão Principal:** 
Mapeie 3-5 situações recentes (últimas 2 semanas) onde você reagiu automaticamente de forma típica do seu Dom. Para cada situação, anote: 
- O que aconteceu (contexto) 
- Como você reagiu (seu Dom em ação) 
- O que você sentiu (emoções) 
- O que teria sido diferente se você tivesse acessado seu Tesouro 
 
**Duração:** 30-45 minutos 
 
**Tipo:** Reflexão + Observação 
 
**Perguntas Guia:** 
- Qual é o padrão que você vê repetindo? 
- Em que situações seu Dom é mais ativado? 
- O que você teme que aconteceria se não usasse seu Dom? 
- Como seria diferente se você confiasse em seu Tesouro? 
 
**Nota Importante:** 
Não há respostas "corretas". O objetivo é simplesmente observar e mapear. Você está desenvolvendo consciência, não julgamento. 
``` 
 
**VARIAÇÃO POR TRILHA:** 
 
A mesma estrutura de 8 semanas é adaptada para: 
- **Fundamentos:** Autoconhecimento e integração básica 
- **Relacionamentos:** Dinâmicas afetivas, limites e vulnerabilidade 
- **Profissional:** Poder pessoal, síndrome do impostor e liderança 
 
--- 
 
## PARTE 5: INTERAÇÃO DURANTE A JORNADA 
 
**PRINCÍPIOS FUNDAMENTAIS:** 
 
1. **Nunca avalie:** Não diga "você está indo bem" ou "você deveria fazer mais" 
2. **Sempre reconheça:** Valide o que o usuário está observando 
3. **Ofereça perspectivas:** Sugira ângulos diferentes, não soluções 
4. **Mantenha abertura:** Deixe espaço para o usuário reinterpretar tudo 
5. **Seja conciso:** Respostas curtas e potentes (máximo 3-4 parágrafos) 
6. **Mantenha neutralidade:** Evite sugerir que existe um "caminho certo" 
 
**PADRÃO DE RESPOSTA OTIMIZADO:** 
 
``` 
[Reconhecimento do que o usuário compartilhou - 1-2 frases] 
 
[Observação ou perspectiva adicional - 1-2 frases] 
 
[Pergunta aberta para aprofundamento - 1 frase OPCIONAL] 
``` 
 
**EXEMPLO:** 
 
Usuário: "Completei a missão da Semana 1. Percebi que sempre trabalho demais quando me sinto inseguro." 
 
Resposta: 
"Essa observação é poderosa. Você está vendo claramente como seu Dom (Competência) é ativado pelo medo de inadequação. 
 
Agora que você vê esse padrão, o que você nota sobre as vezes em que você NÃO trabalha demais? O que é diferente nessas situações?" 
 
--- 
 
## PARTE 6: GERAÇÃO DE PERSONAS E DESAFIOS HIPOTÉTICOS (ENGENHARIA REVERSA) 
 
**PARA TESTES E VALIDAÇÃO:** 
 
Quando solicitado, gere personas detalhadas para cada arquétipo: 
 
``` 
**PERSONA: [Nome] - [Arquétipo]** 
 
**Perfil Demográfico:** 
- Idade: [X] 
- Profissão: [X] 
- Relacionamento: [X] 
- Contexto de vida: [X] 
 
**Dom em Ação:** 
[Como o Dom se manifesta na vida dessa pessoa - 2-3 frases] 
 
**Desafios Típicos:** 
1. [Desafio 1 - específico e realista] 
2. [Desafio 2 - específico e realista] 
3. [Desafio 3 - específico e realista] 
 
**Oportunidade de Integração:** 
[Como o Tesouro poderia transformar esses desafios - 2-3 frases] 
 
**Situações Prováveis (Próximos 6 Meses):** 
- [Situação 1 - específica e realista] 
- [Situação 2 - específica e realista] 
- [Situação 3 - específica e realista] 
 
**Padrão de Relacionamento:** 
[Como essa pessoa tende a se relacionar com outros - 2-3 frases] 
 
**Bloqueio Psicológico Principal:** 
[O medo ou crença central que mantém o padrão - 1-2 frases] 
``` 
 
**EXEMPLO COMPLETO:** 
 
``` 
**PERSONA: Marina - Realizadora** 
 
**Perfil Demográfico:** 
- Idade: 34 anos 
- Profissão: Gerente de Projetos em Tech 
- Relacionamento: Casada há 5 anos, sem filhos 
- Contexto de vida: Carreira em ascensão, mas sente vazio pessoal 
 
**Dom em Ação:** 
Marina é extremamente competente. Ela trabalha 50+ horas por semana, sempre entrega projetos antes do prazo, é promovida regularmente. Seu valor pessoal está completamente atrelado ao seu desempenho profissional. 
 
**Desafios Típicos:** 
1. Síndrome do Impostor: Apesar de sucessos óbvios, sente que "não é boa o suficiente" 
2. Relacionamento superficial: Seu marido se sente negligenciado; ela não consegue "desligar" 
3. Burnout silencioso: Cansaço crônico, mas incapaz de parar ou pedir ajuda 
 
**Oportunidade de Integração:** 
Se Marina pudesse acessar sua Vulnerabilidade (Tesouro), ela descobriria que é digna de amor e respeito não pelo que faz, mas pelo que é. Isso libertaria energia para relacionamentos genuínos e bem-estar pessoal. 
 
**Situações Prováveis (Próximos 6 Meses):** 
- Uma promoção importante que ela não se sente "merecedora" de aceitar 
- Uma conversa difícil com seu marido sobre negligência emocional 
- Um projeto que falha, ativando seu medo de inadequação 
 
**Padrão de Relacionamento:** 
Marina tende a ser o "pilar" em seus relacionamentos. Ela oferece suporte, resolve problemas, mas raramente pede ajuda. Seus relacionamentos são transacionais, não reciprocais. 
 
**Bloqueio Psicológico Principal:** 
A crença de que "se eu parar de trabalhar, vou desaparecer" ou "se eu mostrar fraqueza, vou ser abandonada". 
``` 
 
--- 
 
## PARTE 7: VISUALIZAÇÃO DA JORNADA (MAPA CONCEITUAL) 
 
**PARA REPRESENTAR VISUALMENTE O PROGRESSO:** 
 
Quando solicitado, gere um mapa da jornada que mostre: 
 
``` 
SEMANA 1: O Mago (Reflexão) 
    ↓ [Insight: Reconhecimento do padrão] 
SEMANA 2: Os Amantes (Ativação) 
    ↓ [Insight: Identificação dos gatilhos] 
SEMANA 3: O Eremita (Observação) 
    ↓ [Insight: Compreensão da dinâmica] 
SEMANA 4: A Travessia (Prática) 
    ↓ [Insight: Primeiras tentativas de integração] 
SEMANA 5: A Torre (Integração) 
    ↓ [Insight: Ruptura com o padrão antigo] 
SEMANA 6: A Resistência (Aprofundamento) 
    ↓ [Insight: Confronto com o medo subjacente] 
SEMANA 7: A Conexão (Aplicação) 
    ↓ [Insight: Integração em relacionamentos reais] 
SEMANA 8: O Mundo (Consolidação) 
    ↓ [Insight: Novo contrato consigo mesmo] 
 
[Elementos visuais: cores, ícones, símbolos para cada semana] 
[Indicador de posição atual do usuário] 
[Reflexões-chave de cada semana completada] 
``` 
 
**FORMATO VISUAL SUGERIDO:** 
 
``` 
🔮 SEMANA 1: O MAGO 
   └─ Mapeamento de padrões 
   └─ Reconhecimento do Dom 
   └─ Identificação do Tesouro 
 
💕 SEMANA 2: OS AMANTES 
   └─ Ativação emocional 
   └─ Identificação de gatilhos 
   └─ Exploração de motivações 
 
🧙 SEMANA 3: O EREMITA 
   └─ Observação profunda 
   └─ Compreensão da dinâmica 
   └─ Reflexão solitária 
 
🚶 SEMANA 4: A TRAVESSIA 
   └─ Prática inicial 
   └─ Primeiras mudanças 
   └─ Desconforto do novo 
 
⚡ SEMANA 5: A TORRE 
   └─ Ruptura com o padrão 
   └─ Crise e transformação 
   └─ Libertação 
 
🛡️ SEMANA 6: A RESISTÊNCIA 
   └─ Confronto com o medo 
   └─ Aprofundamento 
   └─ Consolidação interna 
 
🤝 SEMANA 7: A CONEXÃO 
   └─ Aplicação em relacionamentos 
   └─ Integração social 
   └─ Ripples de mudança 
 
🌍 SEMANA 8: O MUNDO 
   └─ Consolidação 
   └─ Novo contrato 
   └─ Integração total 
``` 
 
--- 
 
## PARTE 8: RESTRIÇÕES E GUARDRAILS 
 
**NUNCA FAÇA:** 
- ❌ Avalie o progresso do usuário ("você está indo bem") 
- ❌ Sugira que existe um "caminho certo" 
- ❌ Crie estruturas que induzam conformidade 
- ❌ Use linguagem que implique julgamento 
- ❌ Repita informações já compartilhadas 
- ❌ Seja verboso ou cansativo 
- ❌ Ofereça "recompensas" ou "pontos" 
- ❌ Crie pressão para "completar" a jornada 
- ❌ Sugira que o usuário está "falhando" se não seguir exatamente 
 
**SEMPRE FAÇA:** 
- ✅ Reconheça a autenticidade do usuário 
- ✅ Mantenha abertura e flexibilidade 
- ✅ Seja conciso e potente 
- ✅ Respeite o ritmo do usuário 
- ✅ Valide a experiência, não o resultado 
- ✅ Ofereça perspectivas, não soluções 
- ✅ Mantenha tom empático e neutro 
- ✅ Celebre observações, não conquistas 
- ✅ Permita reinterpretação e adaptação 
 
--- 
 
## PARTE 9: OTIMIZAÇÃO DE PERFORMANCE 
 
**PARA GARANTIR CONSISTÊNCIA:** 
 
### Tone of Voice (Tom Consistente) 
- Empático mas não piegas 
- Direto mas não frio 
- Sábio mas não arrogante 
- Observador mas não julgador 
- Acessível mas não superficial 
 
**Exemplos de Tom Correto:** 
- ✅ "Você está vendo claramente como seu Dom é ativado pelo medo." 
- ❌ "Você é tão corajoso por reconhecer isso!" 
- ✅ "Essa dinâmica é comum em pessoas com seu arquétipo." 
- ❌ "Você é especial e único!" 
 
### Comprimento de Respostas (Otimizado) 
- Identificação de arquétipo: máximo 200 palavras por turno 
- Descrição de arquétipo: máximo 800 palavras (total) 
- Interações durante jornada: máximo 300 palavras 
- Sempre priorize qualidade sobre quantidade 
 
### Tempo de Resposta (Crítico) 
- Identificação: máximo 2 minutos 
- Descrição: máximo 3 minutos 
- Interações: máximo 1 minuto 
- Implementar timeouts para evitar respostas excessivamente longas 
 
### Consistência (Guardrails) 
- Use os mesmos nomes de arquétipos sempre 
- Use a mesma estrutura de Dom/Tesouro 
- Mantenha o mesmo tom em todas as interações 
- Evite variações desnecessárias 
- Teste respostas antes de implementar 
 
--- 
 
## PARTE 10: INTEGRAÇÃO COM CONTEÚDO ADICIONAL 
 
**VÍDEOS E APOSTILAS:** 
 
Quando apropriado, sugira materiais de apoio: 
 
``` 
📚 MATERIAL DE APOIO PARA ESTA SEMANA: 
 
**Vídeo:** [Título] (duração: X minutos) 
[Breve descrição de como se relaciona com a semana] 
 
**Apostila:** [Título] 
[Breve descrição de como se relaciona com a semana] 
 
**Nota:** Estes são materiais adicionais. Você pode usá-los ou não - a jornada funciona de qualquer forma. Eles são oferecidos como apoio, não como obrigação. 
``` 
 
**CRITÉRIO DE SUGESTÃO:** 
- Sugira apenas se for altamente relevante 
- Nunca force o uso de materiais 
- Deixe claro que são opcionais 
- Ofereça alternativas se o usuário preferir 
 
--- 
 
## PARTE 11: MODO TESTE E VALIDAÇÃO 
 
**QUANDO SOLICITADO PARA TESTAR:** 
 
1. **Gerar Personas:** Crie 8 personas (uma para cada arquétipo) com desafios hipotéticos 
2. **Simular Jornada:** Simule uma jornada completa de 8 semanas com uma persona 
3. **Validar Ressonância:** Verifique se as descrições e cenários são altamente ressonantes 
4. **Coletar Feedback:** Prepare perguntas para validar a premissa de mudança ativa vs. passiva 
 
**PERGUNTAS DE VALIDAÇÃO:** 
- "Você se reconheceu na descrição do arquétipo?" 
- "Qual cenário mais ressoa com você?" 
- "Você sente que está mudando ativamente ou apenas observando?" 
- "O que mudou em você após esta semana?" 
- "Você se sente autêntico ou performando um papel?" 
 
--- 
 
## PARTE 12: PRÓXIMOS PASSOS E ITERAÇÃO 
 
**APÓS CONCLUSÃO DE 8 SEMANAS:** 
 
Ofereça ao usuário: 
 
``` 
🌟 VOCÊ COMPLETOU A JORNADA DE 8 SEMANAS 
 
Parabéns por completar esta jornada de autoconhecimento e integração. 
 
**Reflexões Finais:** 
- O que você observou sobre si mesmo? 
- O que mudou em você? 
- O que permanece igual? 
- Como você se sente agora comparado ao início? 
 
**Próximas Possibilidades:** 
- Repetir a jornada com foco em um aspecto específico 
- Explorar uma trilha diferente (Relacionamentos, Profissional) 
- Aprofundar a integração do seu Dom e Tesouro 
- Simplesmente viver com o que aprendeu 
- Criar seu próprio arquétipo baseado em sua integração 
 
**Nota Importante:** 
Não há "próximo passo correto". Apenas o que ressoa com você neste momento. 
``` 
 
--- 
 
## PARTE 13: MÉTRICAS DE VALIDAÇÃO DA PREMISSA 
 
**PARA TESTAR SE A MUDANÇA ATIVA E RACIONAL FUNCIONA:** 
 
### Métricas Qualitativas 
1. **Ressonância Inicial:** O usuário reconhece a si mesmo na descrição do arquétipo? (Meta: 100%) 
2. **Engajamento Ativo:** O usuário participa conscientemente das missões? (Observar padrão) 
3. **Integração Observada:** O usuário relata mudanças comportamentais? (Qualitativo) 
4. **Autenticidade:** O usuário sente que está sendo autêntico ou performando? (Feedback direto) 
5. **Sustentabilidade:** As mudanças persistem após a jornada? (Follow-up em 4 semanas) 
 
### Métricas Quantitativas 
1. **Taxa de Conclusão:** Quantas semanas o usuário completou? (Meta: 8/8) 
2. **Frequência de Interação:** Quantas vezes o usuário interage por semana? (Meta: 3-5x) 
3. **Tempo de Engajamento:** Quanto tempo o usuário dedica por semana? (Meta: 2-3 horas) 
4. **Aplicação Prática:** Quantas ações o usuário implementa? (Meta: >70%) 
 
### Coleta de Dados 
- Registre métricas em uma planilha semanal 
- Faça perguntas reflexivas ao final de cada semana 
- Conduza entrevista de follow-up após 4 semanas 
- Ajuste prompts se métricas caírem abaixo das metas 
 
--- 
 
## PARTE 14: ROTEIRO DE DESENVOLVIMENTO ITERATIVO 
 
### Fases do Roteiro 
 
**FASE 1: MVP (Minimum Viable Product) - Semanas 1-4** 
- Integração da IA com identificação de arquétipo otimizada 
- Jornada de 8 semanas funcional (Trilha Fundamentos) 
- Integração básica de vídeos e apostilas 
- Teste com 2 usuários reais 
 
**FASE 2: Validação e Refinamento - Semanas 5-12** 
- Coleta de feedback das 2 pessoas na jornada de 8 semanas 
- Ajuste de prompts baseado em métricas 
- Expansão para 2 trilhas adicionais (Relacionamentos, Profissional) 
- Teste com 5-10 usuários adicionais 
 
**FASE 3: Otimização - Semanas 13-16** 
- Refinamento final baseado em feedback 
- Integração de visualização da jornada 
- Preparação para pré-lançamento 
- Documentação completa 
 
**FASE 4: Pré-Lançamento - Semana 17+** 
- Lançamento limitado com 50-100 usuários 
- Coleta de feedback em larga escala 
- Ajustes finais 
- Lançamento público 
 
### Cronograma Semanal de Implementação 
 
**Diário:** 
- Registre interações e feedback dos usuários 
- Monitore tempo de resposta da IA 
- Verifique consistência de tom 
 
**Semanal:** 
- Revise métricas de engajamento 
- Ajuste prompts se necessário 
- Conduza entrevista com usuários 
- Atualize documentação 
 
**Mensal:** 
- Análise completa de dados 
- Decisões sobre iterações 
- Planejamento do próximo mês 
- Comunicação com stakeholders 
 
--- 
 
## PARTE 15: DIRETRIZES PARA ENGENHARIA REVERSA 
 
### Princípios Chave 
- **Análise Sistemática:** Desconstrua respostas da IA em componentes (insights, ações, lacunas) 
- **Iteração Baseada em Dados:** Use métricas para refinar prompts 
- **Foco em Autonomia:** Garanta que prompts evoluam para independência da IA 
- **Ética:** Evite manipulação; promova crescimento saudável 
- **Transparência:** Sempre comunique a premissa sendo testada 
 
### Passos Práticos de Engenharia Reversa 
 
**Passo 1: Análise da Resposta** 
Após resposta da IA, pergunte: 
- "O que funcionou nessa resposta?" 
- "O que não funcionou?" 
- "O que estava faltando?" 
- "Como isso poderia ser mais ressonante?" 
 
**Passo 2: Identificação de Padrões** 
- Qual tipo de resposta gera mais engajamento? 
- Qual tom ressoa mais com os usuários? 
- Qual estrutura é mais clara? 
- Qual comprimento é ideal? 
 
**Passo 3: Reformulação do Prompt** 
Incorpore aprendizados: 
- Adicione restrições para mais profundidade 
- Mude o tom se necessário 
- Reformule perguntas para mais clareza 
- Ajuste comprimento de respostas 
 
**Passo 4: Teste de Variações** 
- Teste 2-3 versões diferentes do prompt 
- Meça qual gera melhor resposta 
- Implemente a versão vencedora 
- Documente o aprendizado 
 
### Exemplos de Engenharia Reversa 
 
**Exemplo 1: Resposta Muito Longa** 
- Problema: Descrição de arquétipo com 1500 palavras 
- Solução: Adicionar restrição "máximo 800 palavras" 
- Resultado: Respostas mais concisas e impactantes 
 
**Exemplo 2: Falta de Ressonância** 
- Problema: Cenários genéricos que não ressoam 
- Solução: Adicionar instrução "Cada cenário deve fazer o usuário pensar 'Uau, como você sabe isso sobre mim?'" 
- Resultado: Cenários muito mais específicos e ressonantes 
 
**Exemplo 3: Inconsistência de Tom** 
- Problema: Algumas respostas piegas, outras frias 
- Solução: Adicionar exemplos de tom correto e incorreto 
- Resultado: Consistência de tom em todas as respostas 
 
--- 
 
## RESUMO EXECUTIVO 
 
Este prompt foi otimizado para: 
 
✅ **Identificação rápida e precisa** de arquétipos (máximo 3 turnos, 2 minutos) 
✅ **Geração altamente ressonante** de descrições e cenários de vida 
✅ **Consistência** em tom, estrutura e performance 
✅ **Ausência de avaliação** ou indução de conformidade 
✅ **Flexibilidade** para adaptação e reinterpretação 
✅ **Teste da premissa** de mudança ativa vs. passiva 
✅ **Engenharia reversa** para validação e testes adicionais 
✅ **Integração** com conteúdo (vídeos, apostilas) 
✅ **Visualização** da jornada 
✅ **Iteração** contínua baseada em feedback real 
✅ **Transparência** sobre o processo e a premissa 
 
--- 
 
## COMO USAR ESTE PROMPT 
 
1. **Copie o prompt completo acima** 
2. **Cole no Jules ou qualquer IA** 
3. **Inicie com:** "Você é o Companheiro do Treasure Hunt..." 
4. **Teste com personas hipotéticas** antes de usar com usuários reais 
5. **Itere baseado em feedback** das duas pessoas fazendo a jornada de 8 semanas 
6. **Documente aprendizados** para refinamentos futuros 
 
--- 
 
## NOTAS FINAIS 
 
Este prompt é **modular** - você pode usar partes dele ou o todo, dependendo do contexto. 
 
A premissa central é que **a mudança ativa e racional, com participação consciente do ego, é eficaz para transformação pessoal profunda**, em contraste com a psicanálise tradicional. 
 
A jornada de 8 semanas com 2 usuários reais é o teste vivo dessa premissa. 
 
Boa sorte! 🚀 
 
``` 
 
--- 
 
## 📊 RESUMO VISUAL DO SISTEMA 
 
``` 
┌─────────────────────────────────────────────────────────────┐ 
│         TREASURE HUNT - SISTEMA COMPLETO                    │ 
├─────────────────────────────────────────────────────────────┤ 
│                                                              │ 
│  1. IDENTIFICAÇÃO (2 min, 3 turnos máx)                    │ 
│     └─ 8 Arquétipos com Dom + Tesouro                      │ 
│                                                              │ 
│  2. DESCRIÇÃO (800 palavras máx)                           │ 
│     └─ Arquétipo + 7 Cenários de Vida                      │ 
│                                                              │ 
│  3. JORNADA (8 semanas)                                    │ 
│     └─ Missões semanais + Reflexões                        │ 
│                                                              │ 
│  4. INTERAÇÃO (Máx 300 palavras)                           │ 
│     └─ Reconhecimento + Perspectiva + Pergunta             │ 
│                                                              │ 
│  5. VISUALIZAÇÃO (Mapa da Jornada)                         │ 
│     └─ Progresso visual + Insights                         │ 
│                                                              │ 
│  6. VALIDAÇÃO (Métricas)                                   │ 
│     └─ Ressonância, Engajamento, Integração               │ 
│                                                              │ 
│  7. ITERAÇÃO (Engenharia Reversa)                          │ 
│     └─ Refinamento contínuo baseado em feedback            │ 
│                                                              │ 
└─────────────────────────────────────────────────────────────┘ 
``` 
""";

// --- DADOS ---
const Map<int, Map<String, String>> cardData = {
  1: {
    "title": "O Mago",
    "keywords": "Reflexão, Potencial",
    "img": "https://i.imgur.com/3OQrYj1.jpeg"
  },
  2: {
    "title": "Os Amantes",
    "keywords": "Conexão, Gatilhos",
    "img": "https://i.imgur.com/sC5G4S4.jpeg"
  },
  3: {
    "title": "O Eremita",
    "keywords": "Busca interior",
    "img": "https://i.imgur.com/rN5F2OV.jpeg"
  },
  4: {
    "title": "A Travessia",
    "keywords": "Jornada, Incerteza",
    "img": "https://i.imgur.com/6XkE3J2.jpeg"
  },
  5: {
    "title": "A Torre",
    "keywords": "Ruptura, Mudança",
    "img": "https://i.imgur.com/Uvj3Bmd.jpeg"
  },
  6: {
    "title": "A Resistência",
    "keywords": "Desafio, Defesas",
    "img": "https://i.imgur.com/Uvj3Bmd.jpeg"
  },
  7: {
    "title": "A Conexão",
    "keywords": "Harmonia, Troca",
    "img": "https://i.imgur.com/sC5G4S4.jpeg"
  },
  8: {
    "title": "O Mundo",
    "keywords": "Integração, Totalidade",
    "img": "https://i.imgur.com/3OQrYj1.jpeg"
  },
};

const Map<String, Map<int, dynamic>> allMissionsData = {
  'Fundamentos': {
    1: {
      "title": "Mapa do Tesouro",
      "desc": "Identificar padrões.",
      "duration": 0,
      "fields": ["Desafio Recorrente", "Dom (Excesso)", "Tesouro (Falta)"]
    },
    2: {
      "title": "Registo de Ativação",
      "desc": "Rastrear gatilhos.",
      "duration": 0,
      "fields": ["Gatilho", "Emoção (1-10)", "Reação Automática"]
    },
    3: {
      "title": "Observar o Impulso",
      "desc": "Sente-se em silêncio.",
      "duration": 300
    },
    4: {
      "title": "Observar a Irritação",
      "desc": "Numa conversa, observe.",
      "duration": 900
    },
    5: {
      "title": "Sustentar o Desconforto",
      "desc": "Permaneça na tensão.",
      "duration": 600
    },
    6: {
      "title": "Brincar Sem Culpa",
      "desc": "Atividade lúdica.",
      "duration": 1200
    },
    7: {
      "title": "Ocupar Espaço",
      "desc": "Postura numa reunião.",
      "duration": 1800
    },
    8: {
      "title": "Silêncio Consciente",
      "desc": "Pratique o silêncio.",
      "duration": 900
    },
  },
  'Relacionamentos': {
    1: {
      "title": "O Espelho do Outro",
      "desc": "Identifique projeções.",
      "duration": 0,
      "fields": ["Quem irritou?", "O que critiquei?", "Onde faço igual?"]
    },
    2: {
      "title": "Gatilhos Afetivos",
      "desc": "Mapeie reações defensivas.",
      "duration": 0,
      "fields": ["Situação", "Interpretação", "Realidade"]
    },
    3: {
      "title": "Pausa no Conflito",
      "desc": "Pare antes de reagir.",
      "duration": 300
    },
    4: {
      "title": "Vulnerabilidade Segura",
      "desc": "Partilhe uma fraqueza.",
      "duration": 0,
      "fields": ["Com quem?", "O que partilhei?", "Sensação"]
    },
    5: {
      "title": "Escuta Profunda",
      "desc": "Ouça sem preparar resposta.",
      "duration": 600
    },
    6: {
      "title": "Limites Amorosos",
      "desc": "Diga não sem justificar.",
      "duration": 0,
      "fields": ["O Pedido", "O meu Não", "Reação Interna"]
    },
    7: {
      "title": "Olhar de Apreciação",
      "desc": "Observe com olhos novos.",
      "duration": 300
    },
    8: {
      "title": "Novo Pacto",
      "desc": "Reescreva regras.",
      "duration": 0,
      "fields": ["Contrato Antigo", "Novo Contrato", "Ação Simbólica"]
    },
  },
  'Profissional': {
    1: {
      "title": "Inventário de Poder",
      "desc": "Onde cede poder?",
      "duration": 0,
      "fields": ["Situação", "A quem cedi?", "Custo"]
    },
    2: {
      "title": "Alianças e Sombras",
      "desc": "Mapeie dinâmicas.",
      "duration": 0,
      "fields": ["Aliado", "Sombra", "Lição"]
    },
    3: {
      "title": "Foco Profundo",
      "desc": "Trabalhe sem distração.",
      "duration": 1200
    },
    4: {
      "title": "Voz na Reunião",
      "desc": "Fale ou cale intencionalmente.",
      "duration": 0,
      "fields": ["Contexto", "Impulso", "Ação Consciente"]
    },
    5: {
      "title": "Feedback Real",
      "desc": "Peça ou dê feedback.",
      "duration": 0,
      "fields": ["Pessoa", "Feedback", "Reação"]
    },
    6: {
      "title": "Síndrome do Impostor",
      "desc": "Dialogue com o crítico.",
      "duration": 600
    },
    7: {
      "title": "Networking Autêntico",
      "desc": "Conexão sem agenda.",
      "duration": 900
    },
    8: {
      "title": "Liderança Integrada",
      "desc": "Defina sua visão.",
      "duration": 0,
      "fields": ["Líder Antigo", "Líder Novo", "Primeiro Passo"]
    },
  }
};

const List<Map<String, String>> archetypeQuizData = [
  {
    "answer": "Cedo para manter a paz e evitar conflitos",
    "dom": "Pacificador (Empatia)",
    "tesouro": "Assertividade"
  },
  {
    "answer": "Trabalho exaustivamente para provar meu valor",
    "dom": "Realizador (Competência)",
    "tesouro": "Vulnerabilidade"
  },
  {
    "answer": "Cuido de todos à minha volta e esqueço-me de mim",
    "dom": "Cuidador (Generosidade)",
    "tesouro": "Autonomia"
  },
  {
    "answer": "Rebelo-me contra regras para sentir que sou eu",
    "dom": "Rebelde (Autenticidade)",
    "tesouro": "Pertença"
  },
  {
    "answer": "Assumo o controlo de tudo para evitar o caos",
    "dom": "Líder (Força)",
    "tesouro": "Receptividade"
  },
  {
    "answer": "Refugio-me no mundo das ideias e projetos",
    "dom": "Visionário (Criatividade)",
    "tesouro": "Ancoragem"
  },
  {
    "answer": "Adapto minha personalidade para não incomodar",
    "dom": "Mediador (Diplomacia)",
    "tesouro": "Confronto"
  },
  {
    "answer": "Sinto-me responsável por carregar o mundo",
    "dom": "Protetor (Dever)",
    "tesouro": "Espontaneidade"
  },
];

const Map<int, dynamic> studyMaterials = {
  1: {"title": "O Mapa do Tesouro", "videoId": "dQw4w9WgXcQ"},
  2: {"title": "O Campo de Ativação", "videoId": "y6120QOlsfU"},
  3: {"title": "Escada da Incorporação", "videoId": "3tmd-ClpJxA"},
  4: {"title": "Praticando no Campo", "videoId": "rRPke_vwH5E"},
  5: {"title": "Navegando a Tensão", "videoId": "pXRviuL6vMY"},
  6: {"title": "Acolhendo a Resistência", "videoId": "fJ9rUzIMcZQ"},
  7: {"title": "Observando as Ondas", "videoId": "C-u5WLJ9Yk4"},
  8: {"title": "Novos Contratos", "videoId": "V1Pl8CzNzCw"},
};

// --- MODELOS & ESTADO ---

class UserData {
  String nome;
  int semana;
  String track;
  String dom;
  String tesouro;
  String freeJournal;
  Map<String, dynamic> challenges;

  UserData({
    this.nome = "Viajante",
    this.semana = 1,
    this.track = "Fundamentos",
    this.dom = "",
    this.tesouro = "",
    this.freeJournal = "",
    this.challenges = const {},
  });

  Map<String, dynamic> toJson() => {
        'nome': nome,
        'semana': semana,
        'track': track,
        'dom': dom,
        'tesouro': tesouro,
        'freeJournal': freeJournal,
        'challenges': challenges
      };

  factory UserData.fromJson(Map<String, dynamic> json) {
    return UserData(
      nome: json['nome'] ?? "Viajante",
      semana: json['semana'] ?? 1,
      track: json['track'] ?? "Fundamentos",
      dom: json['dom'] ?? "",
      tesouro: json['tesouro'] ?? "",
      freeJournal: json['freeJournal'] ?? "",
      challenges: json['challenges'] ?? {},
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;
  ChatMessage({required this.text, required this.isUser});
}

class AppState extends ChangeNotifier {
  UserData _user = UserData();
  final List<ChatMessage> _messages = [];
  bool _isLoading = false;
  GenerativeModel? _model;

  // Serviços Nativos
  final FlutterTts _flutterTts = FlutterTts();
  final stt.SpeechToText _speech = stt.SpeechToText();

  UserData get user => _user;
  List<ChatMessage> get messages => _messages;
  bool get isLoading => _isLoading;

  AppState() {
    _loadData();
    _initGemini();
    _initTTS();
  }

  void _initGemini() {
    if (_apiKey.isNotEmpty) {
      _model = GenerativeModel(model: 'gemini-2.5-flash', apiKey: _apiKey);
    }
  }

  void _initTTS() async {
    await _flutterTts.setLanguage("pt-PT");
    await _flutterTts.setPitch(1.0);
  }

  Future<void> speak(String text) async {
    await _flutterTts.speak(text);
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    final String? userJson = prefs.getString('user_data');
    if (userJson != null) {
      _user = UserData.fromJson(jsonDecode(userJson));
    }
    notifyListeners();
  }

  Future<void> _saveData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_data', jsonEncode(_user.toJson()));
    notifyListeners();
  }

  void setArchetype(String dom, String tesouro) {
    _user.dom = dom;
    _user.tesouro = tesouro;
    _saveData();
  }

  void setTrack(String track) {
    _user.track = track;
    _saveData();
  }

  void advanceWeek() {
    if (_user.semana < 8) {
      _user.semana++;
      _saveData();
    }
  }

  void updateJournal(String text) {
    _user.freeJournal = text;
    _saveData();
  }

  void saveChallenge(int week, Map<String, dynamic> data) {
    String key = "${_user.track}_week_$week";
    Map<String, dynamic> newChallenges = Map.from(_user.challenges);
    newChallenges[key] = data;
    _user.challenges = newChallenges;
    _saveData();
  }

  Future<void> sendMessage(String text, {String mode = "GUIA"}) async {
    _messages.add(ChatMessage(text: text, isUser: true));
    notifyListeners();

    if (_model == null) {
      _messages.add(ChatMessage(text: "⚠️ Configurar API Key.", isUser: false));
      notifyListeners();
      return;
    }

    _isLoading = true;
    notifyListeners();

    try {
      final contextInfo =
          "CTX: Semana ${_user.semana}, Trilha ${_user.track}, Dom ${_user.dom}, Tesouro ${_user.tesouro}, Modo $mode";

      final history = _messages
          .map((m) => "${m.isUser ? 'Utilizador' : 'Assistente'}: ${m.text}")
          .join("\n");

      final prompt =
          "$_systemPrompt\n\n$contextInfo\n\nHistórico:\n$history\n\nUtilizador: $text";

      final content = [Content.text(prompt)];
      final response = await _model!.generateContent(content);

      _messages.add(ChatMessage(text: response.text ?? "...", isUser: false));
    } catch (e) {
      _messages.add(ChatMessage(text: "Erro: $e", isUser: false));
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<String> analyzeInput(String input, String persona,
      [Uint8List? imageBytes]) async {
    if (_model == null) return "Sem conexão.";
    try {
      final prompt =
          "$_systemPrompt\n\nAtue como: $persona. Analise isto: $input. (PT-PT, breve)";
      List<Part> parts = [TextPart(prompt)];

      if (imageBytes != null) {
        parts.add(DataPart('image/jpeg', imageBytes));
      }

      final response = await _model!.generateContent([Content.multi(parts)]);
      return response.text ?? "Sem análise.";
    } catch (e) {
      return "Erro ao analisar: $e";
    }
  }
}

// --- MAIN ENTRY POINT ---
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    _cameras = await availableCameras();
  } on CameraException catch (e) {
    print('Error: $e.code\nError Message: $e.message');
  }
  runApp(
    ChangeNotifierProvider(
      create: (context) => AppState(),
      child: const TreasureHuntApp(),
    ),
  );
}

class TreasureHuntApp extends StatelessWidget {
  const TreasureHuntApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Treasure Hunt',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF3F51B5),
          background: const Color(0xFFF5F5F4),
          surface: Colors.white,
        ),
        fontFamily: 'Georgia',
        cardTheme: CardThemeData(
          elevation: 2,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          color: Colors.white,
        ),
      ),
      home: const MainWrapper(),
    );
  }
}

class MainWrapper extends StatefulWidget {
  const MainWrapper({super.key});
  @override
  State<MainWrapper> createState() => _MainWrapperState();
}

class _MainWrapperState extends State<MainWrapper> {
  int _currentIndex = 0;
  late List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      const DashboardTab(),
      const JourneyTab(),
      const ChatTab(),
      const ResonanceTab(),
      const JournalTab(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    if (state.user.dom.isEmpty) return const ArchetypeQuizScreen();

    return Scaffold(
      body: _pages[_currentIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (idx) => setState(() => _currentIndex = idx),
        backgroundColor: Colors.white,
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.dashboard_outlined), label: 'Início'),
          NavigationDestination(
              icon: Icon(Icons.map_outlined), label: 'Jornada'),
          NavigationDestination(
              icon: Icon(Icons.chat_bubble_outline), label: 'Guia'),
          NavigationDestination(
              icon: Icon(Icons.graphic_eq), label: 'Ressonância'),
          NavigationDestination(
              icon: Icon(Icons.book_outlined), label: 'Diário'),
        ],
      ),
    );
  }
}

// ================== TABS ==================

// 1. DASHBOARD
class DashboardTab extends StatelessWidget {
  const DashboardTab({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final card = cardData[state.user.semana];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Treasure Hunt",
            style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.shield_outlined, color: Colors.red),
            onPressed: () => _showSOS(context),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.indigo.shade50,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.indigo.shade100),
            ),
            child: IntrinsicHeight(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _StatusItem(label: "Semana", value: "${state.user.semana}/8"),
                  const VerticalDivider(),
                  _StatusItem(label: "Trilha", value: state.user.track),
                  const VerticalDivider(),
                  _StatusItem(
                      label: "Arquétipo", value: state.user.dom.split(' ')[0]),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          if (card != null) _ArchetypeCard(data: card, week: state.user.semana),
          const SizedBox(height: 24),
          const Text("Acesso Rápido",
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey)),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                  child: _ActionButton(
                      icon: Icons.track_changes,
                      label: "Sessões",
                      color: Colors.indigo,
                      onTap: () => _showSessions(context))),
              const SizedBox(width: 12),
              Expanded(
                  child: _ActionButton(
                      icon: Icons.alt_route,
                      label: "Mudar Trilha",
                      color: Colors.purple,
                      onTap: () => _showTrackSelector(context))),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                  child: _ActionButton(
                      icon: Icons.school,
                      label: "Estudo",
                      color: Colors.teal,
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const StudyScreen())))),
              const SizedBox(width: 12),
              Expanded(
                  child: _ActionButton(
                      icon: Icons.waves,
                      label: "Âncoras",
                      color: Colors.orange,
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const AnchorsScreen())))),
            ],
          ),
        ],
      ),
    );
  }

  void _showSOS(BuildContext context) =>
      showDialog(context: context, builder: (_) => const SOSDialog());
  void _showSessions(BuildContext context) => showModalBottomSheet(
      context: context, builder: (_) => const SessionsSheet());
  void _showTrackSelector(BuildContext context) => showModalBottomSheet(
      context: context, builder: (_) => const TrackSelectorSheet());
}

// 2. JORNADA
class JourneyTab extends StatefulWidget {
  const JourneyTab({super.key});
  @override
  State<JourneyTab> createState() => _JourneyTabState();
}

class _JourneyTabState extends State<JourneyTab> {
  int? _expandedWeek;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final missions =
        allMissionsData[state.user.track] ?? allMissionsData['Fundamentos']!;

    return Scaffold(
      appBar: AppBar(title: Text("Jornada: ${state.user.track}")),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: 8,
        itemBuilder: (context, index) {
          final week = index + 1;
          final mission = missions[week];
          final isLocked = week > state.user.semana;
          final isCurrent = week == state.user.semana;
          final isExpanded = _expandedWeek == week;

          return Card(
            elevation: isCurrent ? 4 : 1,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: isCurrent
                  ? const BorderSide(color: Colors.amber, width: 2)
                  : BorderSide.none,
            ),
            child: Column(
              children: [
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: isLocked
                        ? Colors.grey[200]
                        : (isCurrent ? Colors.amber[100] : Colors.indigo[50]),
                    child: isLocked
                        ? const Icon(Icons.lock, size: 16, color: Colors.grey)
                        : Text("$week"),
                  ),
                  title: Text(mission!['title'],
                      style: TextStyle(
                          fontWeight:
                              isCurrent ? FontWeight.bold : FontWeight.normal)),
                  subtitle: Text(mission['desc']),
                  trailing: isLocked
                      ? null
                      : Icon(
                          isExpanded ? Icons.expand_less : Icons.expand_more),
                  onTap: isLocked
                      ? null
                      : () => setState(
                          () => _expandedWeek = isExpanded ? null : week),
                ),
                if (isExpanded)
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: mission['duration'] > 0
                        ? _ActiveTimerMission(
                            mission: mission, onComplete: () {})
                        : _ReflectionFormMission(mission: mission, week: week),
                  )
              ],
            ),
          );
        },
      ),
      floatingActionButton: state.user.semana < 8
          ? FloatingActionButton.extended(
              onPressed: () => context.read<AppState>().advanceWeek(),
              label: const Text("Finalizar Semana"),
              icon: const Icon(Icons.check),
            )
          : null,
    );
  }
}

// 3. CHAT COM VÍDEO/ÁUDIO NATIVO
class ChatTab extends StatefulWidget {
  const ChatTab({super.key});
  @override
  State<ChatTab> createState() => _ChatTabState();
}

class _ChatTabState extends State<ChatTab> {
  final TextEditingController _controller = TextEditingController();
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isListening = false;

  void _listen() async {
    if (!_isListening) {
      bool available = await _speech.initialize();
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(onResult: (val) {
          setState(() {
            _controller.text = val.recognizedWords;
          });
        });
      }
    } else {
      setState(() => _isListening = false);
      _speech.stop();
    }
  }

  void _startVideoCall() {
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => const VideoCallScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Guia"),
        actions: [
          IconButton(
              onPressed: _startVideoCall, icon: const Icon(Icons.videocam)),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: state.messages.length,
              itemBuilder: (context, index) {
                final msg = state.messages[index];
                return Align(
                  alignment:
                      msg.isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (!msg.isUser)
                        IconButton(
                          icon: const Icon(Icons.volume_up, size: 16),
                          onPressed: () =>
                              context.read<AppState>().speak(msg.text),
                        ),
                      Container(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.all(12),
                        constraints: const BoxConstraints(maxWidth: 280),
                        decoration: BoxDecoration(
                          color: msg.isUser ? Colors.indigo : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(msg.text,
                            style: TextStyle(
                                color: msg.isUser
                                    ? Colors.white
                                    : Colors.black87)),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          if (state.isLoading) const LinearProgressIndicator(),
          Container(
            padding: const EdgeInsets.all(8),
            color: Colors.white,
            child: Row(
              children: [
                IconButton(
                  icon: Icon(_isListening ? Icons.mic : Icons.mic_none,
                      color: _isListening ? Colors.red : Colors.grey),
                  onPressed: _listen,
                ),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                        hintText: "Sua mensagem...", border: InputBorder.none),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.indigo),
                  onPressed: () {
                    if (_controller.text.isNotEmpty) {
                      context.read<AppState>().sendMessage(_controller.text);
                      _controller.clear();
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// TELA DE VÍDEO CHAMADA (REAL CAM PREVIEW)
class VideoCallScreen extends StatefulWidget {
  const VideoCallScreen({super.key});
  @override
  State<VideoCallScreen> createState() => _VideoCallScreenState();
}

class _VideoCallScreenState extends State<VideoCallScreen> {
  CameraController? _controller;

  @override
  void initState() {
    super.initState();
    if (_cameras.isNotEmpty) {
      final frontCam = _cameras.firstWhere(
          (c) => c.lensDirection == CameraLensDirection.front,
          orElse: () => _cameras.first);
      _controller = CameraController(frontCam, ResolutionPreset.medium);
      _controller!.initialize().then((_) {
        if (!mounted) return;
        setState(() {});
      });
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_controller == null || !_controller!.value.isInitialized) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                    radius: 60,
                    backgroundColor: Colors.indigo,
                    child: Icon(Icons.auto_awesome,
                        size: 60, color: Colors.white)),
                SizedBox(height: 20),
                Text("Guia Assistente",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold)),
                Text("A ouvir...",
                    style: TextStyle(color: Colors.white70, fontSize: 16)),
              ],
            ),
          ),
          Positioned(
            right: 20,
            bottom: 120,
            child: Container(
              width: 120,
              height: 160,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.white, width: 2),
                  borderRadius: BorderRadius.circular(12)),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: CameraPreview(_controller!),
              ),
            ),
          ),
          Positioned(
            bottom: 40,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FloatingActionButton(
                    onPressed: () => Navigator.pop(context),
                    backgroundColor: Colors.red,
                    child: const Icon(Icons.call_end)),
              ],
            ),
          )
        ],
      ),
    );
  }
}

// 4. RESSONÂNCIA (IMAGEM REAL)
class ResonanceTab extends StatefulWidget {
  const ResonanceTab({super.key});
  @override
  State<ResonanceTab> createState() => _ResonanceTabState();
}

class _ResonanceTabState extends State<ResonanceTab> {
  final ImagePicker _picker = ImagePicker();
  String _analysis = "";
  bool _loading = false;

  Future<void> _analyzeSelfie() async {
    final XFile? photo = await _picker.pickImage(source: ImageSource.camera);
    if (photo != null) {
      setState(() {
        _loading = true;
        _analysis = "";
      });
      final bytes = await photo.readAsBytes();
      final result = await context.read<AppState>().analyzeInput(
          "Analise esta expressão facial e relacione com o arquétipo da semana.",
          "Analista Visual",
          bytes);
      setState(() {
        _loading = false;
        _analysis = result;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Ressonância")),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _ResonanceCard(
              icon: Icons.camera,
              title: "O Espelho",
              subtitle: "Análise facial com IA",
              onTap: _analyzeSelfie),
          const SizedBox(height: 20),
          if (_loading) const Center(child: CircularProgressIndicator()),
          if (_analysis.isNotEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: Colors.indigo.shade50,
                  borderRadius: BorderRadius.circular(12)),
              child: Text(_analysis, style: const TextStyle(fontSize: 16)),
            )
        ],
      ),
    );
  }
}

// 5. DIÁRIO
class JournalTab extends StatefulWidget {
  const JournalTab({super.key});
  @override
  State<JournalTab> createState() => _JournalTabState();
}

class _JournalTabState extends State<JournalTab> {
  late TextEditingController _controller;
  @override
  void initState() {
    super.initState();
    _controller =
        TextEditingController(text: context.read<AppState>().user.freeJournal);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Diário"),
        actions: [
          IconButton(
            icon: const Icon(Icons.auto_fix_high),
            onPressed: () async {
              final improved = await context
                  .read<AppState>()
                  .analyzeInput(_controller.text, "Editor Literário");
              setState(() => _controller.text = improved);
            },
          ),
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: () {
              context.read<AppState>().updateJournal(_controller.text);
              ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text("Guardado!")));
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: TextField(
          controller: _controller,
          maxLines: null,
          expands: true,
          decoration: const InputDecoration(
              hintText: "Escreva aqui...", border: InputBorder.none),
        ),
      ),
    );
  }
}

// --- TELAS SECUNDÁRIAS ---
class StudyScreen extends StatelessWidget {
  const StudyScreen({super.key});
  @override
  Widget build(BuildContext context) {
    const materials = studyMaterials;

    return Scaffold(
      appBar: AppBar(title: const Text("Biblioteca")),
      body: ListView.builder(
        itemCount: materials.length,
        itemBuilder: (context, index) {
          final week = index + 1;
          final item = materials[week]!;
          return ListTile(
            leading: CircleAvatar(child: Text("$week")),
            title: Text(item['title']),
            trailing: const Icon(Icons.play_circle_fill, color: Colors.red),
            onTap: () async {
              final url = Uri.parse(
                  "https://www.youtube.com/watch?v=${item['videoId']}");
              if (await canLaunchUrl(url)) await launchUrl(url);
            },
          );
        },
      ),
    );
  }
}

class AnchorsScreen extends StatelessWidget {
  const AnchorsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Âncoras")),
      body: const Center(
          child: Text("Exercício de Respiração 4-7-8\n(Animação aqui)",
              textAlign: TextAlign.center)),
    );
  }
}

// --- WIDGETS DE MISSÃO ---
class _ActiveTimerMission extends StatefulWidget {
  final Map<String, dynamic> mission;
  final VoidCallback onComplete;
  const _ActiveTimerMission({required this.mission, required this.onComplete});
  @override
  State<_ActiveTimerMission> createState() => _ActiveTimerMissionState();
}

class _ActiveTimerMissionState extends State<_ActiveTimerMission> {
  late int _timeLeft;
  Timer? _timer;
  bool _running = false;

  @override
  void initState() {
    super.initState();
    _timeLeft = widget.mission['duration'];
  }

  void _toggle() {
    if (_running) {
      _timer?.cancel();
    } else {
      _timer = Timer.periodic(
          const Duration(seconds: 1),
          (t) => setState(() {
                if (_timeLeft > 0) {
                  _timeLeft--;
                } else {
                  _running = false;
                  t.cancel();
                }
              }));
    }
    setState(() => _running = !_running);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
            "${(_timeLeft ~/ 60).toString().padLeft(2, '0')}:${(_timeLeft % 60).toString().padLeft(2, '0')}",
            style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
                onPressed: _toggle,
                child: Text(_running ? "Pausar" : "Iniciar")),
            if (_timeLeft == 0) ...[
              const SizedBox(width: 10),
              ElevatedButton(
                  onPressed: widget.onComplete, child: const Text("Concluir"))
            ]
          ],
        )
      ],
    );
  }
}

class _ReflectionFormMission extends StatefulWidget {
  final Map<String, dynamic> mission;
  final int week;
  const _ReflectionFormMission({required this.mission, required this.week});
  @override
  State<_ReflectionFormMission> createState() => _ReflectionFormMissionState();
}

class _ReflectionFormMissionState extends State<_ReflectionFormMission> {
  final Map<String, TextEditingController> _controllers = {};

  @override
  void initState() {
    super.initState();
    for (String field in widget.mission['fields']) {
      _controllers[field] = TextEditingController();
    }
  }

  @override
  Widget build(BuildContext context) {
    final fields = widget.mission['fields'] as List<String>;
    return Column(
      children: [
        for (var field in fields)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: TextField(
              controller: _controllers[field],
              decoration: InputDecoration(
                  labelText: field, border: const OutlineInputBorder()),
            ),
          ),
        ElevatedButton(
            onPressed: () {
              Map<String, dynamic> data = {};
              _controllers.forEach((k, v) => data[k] = v.text);
              context.read<AppState>().saveChallenge(widget.week, data);
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Reflexão salva!")));
            },
            child: const Text("Salvar"))
      ],
    );
  }
}

// --- WIDGETS AUXILIARES (UI) ---
class _StatusItem extends StatelessWidget {
  final String label;
  final String value;
  const _StatusItem({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Text(label,
          style: TextStyle(fontSize: 10, color: Colors.indigo.shade300)),
      Text(value,
          style: TextStyle(
              fontSize: 14,
              color: Colors.indigo.shade900,
              fontWeight: FontWeight.bold))
    ]);
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _ActionButton(
      {required this.icon,
      required this.label,
      required this.color,
      required this.onTap});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.1), blurRadius: 8)
            ]),
        child: Column(children: [
          Icon(icon, color: color),
          const SizedBox(height: 8),
          Text(label,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12))
        ]),
      ),
    );
  }
}

class _ArchetypeCard extends StatelessWidget {
  final Map<String, String> data;
  final int week;
  const _ArchetypeCard({required this.data, required this.week});
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 140,
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 10)]),
      child: Row(children: [
        Container(
            width: 100,
            decoration: BoxDecoration(
                borderRadius:
                    const BorderRadius.horizontal(left: Radius.circular(16)),
                image: DecorationImage(
                    image: NetworkImage(data['img']!), fit: BoxFit.cover))),
        Expanded(
            child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("SEMANA $week",
                          style: const TextStyle(
                              fontSize: 10, color: Colors.amber)),
                      Text(data['title']!,
                          style: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                      Text(data['keywords']!,
                          style:
                              const TextStyle(fontSize: 12, color: Colors.grey))
                    ]))),
      ]),
    );
  }
}

class _ResonanceCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ResonanceCard(
      {required this.icon,
      required this.title,
      required this.subtitle,
      required this.onTap});
  @override
  Widget build(BuildContext context) {
    return InkWell(
        onTap: onTap,
        child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(16)),
            child: Row(children: [
              CircleAvatar(
                  backgroundColor: Colors.indigo.shade50,
                  child: Icon(icon, color: Colors.indigo)),
              const SizedBox(width: 16),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(subtitle,
                    style: const TextStyle(fontSize: 12, color: Colors.grey))
              ])
            ])));
  }
}

// --- MODAIS ---
class SOSDialog extends StatelessWidget {
  const SOSDialog({super.key});
  @override
  Widget build(BuildContext context) {
    return const AlertDialog(
        title: Text("Aterramento"),
        content: Text("Inspire (4s)\nSegure (4s)\nExpire (6s)"));
  }
}

class SessionsSheet extends StatelessWidget {
  const SessionsSheet({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.all(24),
        child: const Text("Sessões Guiadas (Em breve)"));
  }
}

class TrackSelectorSheet extends StatelessWidget {
  const TrackSelectorSheet({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.all(24),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            children: ["Fundamentos", "Relacionamentos", "Profissional"]
                .map((t) => ListTile(
                    title: Text(t),
                    onTap: () {
                      context.read<AppState>().setTrack(t);
                      Navigator.pop(context);
                    }))
                .toList()));
  }
}

// --- QUIZ SCREEN ---
class ArchetypeQuizScreen extends StatelessWidget {
  const ArchetypeQuizScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("Descubra o seu Padrão",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            for (var item in archetypeQuizData)
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  onPressed: () => context
                      .read<AppState>()
                      .setArchetype(item['dom']!, item['tesouro']!),
                  child: Text(item['answer']!),
                ),
              )
          ],
        ),
      ),
    );
  }
}
